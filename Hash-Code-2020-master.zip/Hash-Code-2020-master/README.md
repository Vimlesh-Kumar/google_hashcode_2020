# Hash-Code-2020 

## Installation

conda env create --file environment.yml

source activate Hash-code-2020

python main.py

## Team

* Da Silva Samuele
* Delisle Pierre-Adrien 
* Gaillard Rémi
* Le Palud Yves
