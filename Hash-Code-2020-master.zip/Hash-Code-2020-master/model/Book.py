class Book:
    def __init__(self, id: int, score: int):
        self.id = id
        self.score = score

    def __str__(self):
        # TODO pour simplifier le write
        pass
